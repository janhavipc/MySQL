# MySQL-NorthWind-DataBase

This is a version of the Microsoft Access 2000 Northwind sample database, re-engineered for MySQL.

The Northwind sample database was provided with Microsoft Access as a tutorial schema for managing small business customers, orders, inventory, purchasing, suppliers, shipping, and employees. Northwind is an excellent tutorial schema for a small-business ERP, with customers, orders, inventory, purchasing, suppliers, shipping, employees, and single-entry accounting.

All the TABLES and VIEWS from the MSSQL-2000 version have been converted to MySQL and included here. 

![alt tag](https://github.com/thevedprakash/MySQL-NorthWind-DataBase/blob/master/Northwind_ERD.png)
