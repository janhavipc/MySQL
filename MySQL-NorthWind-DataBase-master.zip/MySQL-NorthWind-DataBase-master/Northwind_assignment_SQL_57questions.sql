select * from shippers;

Select * from categories;

Select category_name,
        description
   from categories;     
   
   select * from employees;
   
   select first_name,
           last_name,
           hire_date 
       from employees
       where title='sales representative'
       and country='USA';
       
   Select * from orders
   where employee_id=5;
   
   Select 
        supplier_id,
        contact_name,
        contact_title
        from suppliers
   where contact_title<> 'Marketing Manager';
   
   Select 
        product_id,
        product_name
        from products
    where product_name like '%queso%';
     
   Select * from orders;
   select 
         order_id,
         customer_id,
         ship_country
     from orders
     where ship_country in ('France', 'Belgium');
     
     select 
         order_id,
         customer_id,
         ship_country
     from orders
     where ship_country in ('Brazil', 'Mexico', 'Argentina', 'Venezuela');
     
     select * from employees;
     select
           first_name,
           last_name,
           title,
           birth_date as DateOnlyBirthDate
      from employees
      order by birth_date asc;
      
select * from employees;

select
    concat(first_name,'  ',last_name )  as Full_Name
     from employees;
   
   
   select * from order_details;
   
   select
        order_id,
        product_id,
        unit_price,
        quantity,
        (unit_price*quantity) as total_price
       from order_details;
       
       select * from customers;
      
      
      select min(order_date) from orders;
      
     select distinct country
     from customers;
    
    select * from customers;
    
    
     
     select distinct contact_title
     from customers;
     
     select * from orders;
     
select  
count(customer_id) 
from customers;

select * from customers;

-- query 21)
     select
            country,
            city,
         count(customer_id)
         from customers
         group by city;
         
     -- query 22)
     select * from products;
     
     select
          product_id,
          product_name,
          units_in_stock,
          reorder_level
          from products
       where units_in_stock<reorder_level;   
     
         -- query 23) 
     select * from products;    
 
     select
          product_id,
          product_name,
          units_in_stock,
          units_on_order,
          reorder_level,
          discontinued
          from products
       where (units_in_stock+units_on_order)<=reorder_level
       and discontinued = 0;  
 
 -- query 24)
 
 select * from customers;
 
 select 
      company_name,
      region,
   count(customer_id)  
   from customers	
   group by company_name
   order by region asc;
   
  ---------------------                QUERY  18
  select * from suppliers;
  select * from products;
  
  select 
        product_id,
        product_name,
        company_name,
    count(product_id)    
  from products
  left join suppliers
  on products.supplier_id=suppliers.supplier_id
  group by product_id;
  
  -------------------------- QUERY 19
  
  select*from shippers;
  
  select 
       order_id,
       order_date,
       shippers.company_name
   from orders
   join shippers
   on shippers.shipper_id=orders.ship_via
   where order_id<10300
   order by order_id;
   
   ----------------------- 	QUERY 20
   select * from categories;
   select * from products;
   
   Select 
         category_name,
    count(product_id)     
   from categories
   join products
   on categories.category_id=products.category_id
   group by category_name
   order by product_id desc;
   
          ----------------- --QUERY 24
  
  Select * from customers;
  select * from region;
  
  select 
       company_name,
       region as region_order,
  count(customer_id)
   from customers
   group by region 
   order by region asc;
   
                            -- QUERY 25
   SELECT *from orders;
   
   select ship_country,
      avg(freight)   
      from orders
      group by ship_country
      order by avg(freight) desc;
      
                            -- QUERY 26
	select
            ship_country,
            order_date,
            avg(freight)   
      from orders
      where year(order_date)= 2015
      group by ship_country
      order by avg(freight) desc;


      ------------------- --Query 27     
      select 
                      ship_country,
                      order_date,
                      avg(freight)   
                     from orders
            where order_date between '2015-01-01' and '2015-12-31'
                group by ship_country
                order by avg(freight) desc;
--- --note- no data found in 2015 year, if year is changed dada is generating

------------- --QUERY28
   select
         ship_country,
          avg(freight)
         from orders
         where
         order_date>=dateadd(yy,-1,(select max(order_date)from orders))
         group by ship_country
         order by avg(freight);
         -- ABOVE QUERY DIDNT WORKED
         
 ------------------ --QUERY29
 
 select 
       employees.employee_id,
       employees.last_name,
       orders.order_id,
        products.product_name,
       order_details.quantity
   from employees
   left join orders
   on employees.employee_id=orders.employee_id
   left join order_details
   on orders.order_id=order_details.order_id
   left join products
   on products.product_id=order_details.product_id;
   
 ------------ --QUERY30
 
 select 
        customers.customer_id,
        orders.order_id
    from orders
    left outer join customers
    on customers.customer_id=orders.customer_id
    where customers.customer_id='null';
 
         
    ------------ --QUERY31
 
 select 
        customers.customer_id,
        orders.order_id
    from orders
    left outer join customers
    on customers.customer_id=orders.customer_id
    where customers.customer_id='null';      
         
         